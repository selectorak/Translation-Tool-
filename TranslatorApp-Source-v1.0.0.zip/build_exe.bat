@echo off
chcp 65001 >/dev/null
title Building 中英翻译助手 Executable

echo ============================================
echo   Building 中英翻译助手 (Chinese-English Translator)
echo ============================================
echo.

cd /d "%~dp0"

REM Check if PyInstaller is installed
pip show pyinstaller >/dev/null 2>&1
if %errorlevel% neq 0 (
    echo [1/3] Installing PyInstaller...
    pip install pyinstaller
) else (
    echo [1/3] PyInstaller already installed.
)

echo [2/3] Cleaning previous builds...
if exist "..\..\translator-app.spec" del "..\..\translator-app.spec"
if exist "..\..\dist" rmdir /s /q "..\..\dist"
if exist "..\..\build" rmdir /s /q "..\..\build"

echo [3/3] Building executable (this may take a few minutes)...
pyinstaller --onedir ^
    --name "TranslatorApp" ^
    --noconfirm ^
    --clean ^
    --add-data "api_keys.json;." ^
    --add-data "theme.py;." ^
    --add-data "config.py;." ^
    --add-data "ui_components.py;." ^
    --add-data "translate_engines.py;." ^
    --add-data "screen_translator.py;." ^
    --add-data "audio_translator.py;." ^
    --add-data "check_deps.py;." ^
    --add-data "requirements.txt;." ^
    --hidden-import "PIL" ^
    --hidden-import "PIL._tkinter_finder" ^
    --hidden-import "cv2" ^
    --hidden-import "pytesseract" ^
    --hidden-import "mss" ^
    --hidden-import "pyttsx3" ^
    --hidden-import "pycaw" ^
    --hidden-import "comtypes" ^
    --hidden-import "faster_whisper" ^
    --collect-submodules "PIL" ^
    translator.py

if %errorlevel% equ 0 (
    echo.
    echo ============================================
    echo   Build successful!
    echo   Output: ..\..\dist\TranslatorApp\
    echo ============================================
) else (
    echo.
    echo ============================================
    echo   Build FAILED! Check the errors above.
    echo ============================================
    pause
)
